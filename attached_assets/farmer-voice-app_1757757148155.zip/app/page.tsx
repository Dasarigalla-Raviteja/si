import { VoiceAssistant } from "@/components/voice-assistant"

export default function Home() {
  const handleWeatherRequest = () => {
    console.log("Weather requested by voice")
    // Add your weather logic here
  }

  const handlePricesRequest = () => {
    console.log("Prices requested by voice")
    // Add your prices logic here
  }

  const handleHelpRequest = () => {
    console.log("Help requested by voice")
    // Add your help logic here
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-green-100 via-blue-50 to-green-50 p-4">
      <div className="container mx-auto py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-green-800 mb-2">Farmer Voice Assistant</h1>
          <p className="text-green-600">Voice-powered farming assistance for low-literate users</p>
        </div>

        <VoiceAssistant
          onWeatherRequest={handleWeatherRequest}
          onPricesRequest={handlePricesRequest}
          onHelpRequest={handleHelpRequest}
          language="hi-IN"
          autoGreet={true}
        />
      </div>
    </main>
  )
}
