"use client"

import React from "react"
import { Button } from "@/components/ui/button"
import { useVoiceSupport } from "@/hooks/use-voice-support"

interface VoiceButtonProps {
  onCommand?: (category: string, command: string) => void
  language?: string
  className?: string
  size?: "sm" | "default" | "lg"
}

export const VoiceButton: React.FC<VoiceButtonProps> = ({
  onCommand,
  language = "hi-IN",
  className = "",
  size = "lg",
}) => {
  const { isListening, isSpeaking, isSupported, currentStatus, speak, startListening, messages, processCommand } =
    useVoiceSupport({ language })

  const handleVoicePress = () => {
    if (!isSupported) {
      alert(messages.notSupported)
      return
    }

    if (isListening || isSpeaking) return

    // Provide immediate audio feedback
    speak("बटन दबाया गया")

    setTimeout(() => {
      startListening()
    }, 800)
  }

  // Handle command processing
  React.useEffect(() => {
    const originalProcessCommand = processCommand

    // Override processCommand to handle external callback
    if (onCommand) {
      // This would need to be implemented differently in the hook
      // For now, we'll handle it in the parent component
    }
  }, [onCommand, processCommand])

  if (!isSupported) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
        <p className="text-red-700 text-center font-medium">{messages.notSupported}</p>
      </div>
    )
  }

  const getButtonText = () => {
    switch (currentStatus) {
      case "listening":
        return "सुन रहा हूं..."
      case "speaking":
        return "बोल रहा हूं..."
      case "processing":
        return "समझ रहा हूं..."
      case "error":
        return "त्रुटि हुई"
      default:
        return "बोलने के लिए दबाएं"
    }
  }

  const getButtonIcon = () => {
    switch (currentStatus) {
      case "listening":
        return "🔴"
      case "speaking":
        return "🔊"
      case "processing":
        return "⚙️"
      case "error":
        return "❌"
      default:
        return "🎙️"
    }
  }

  return (
    <Button
      onClick={handleVoicePress}
      disabled={isSpeaking || isListening}
      size={size}
      className={`
        ${isListening ? "bg-red-500 hover:bg-red-600" : "bg-blue-500 hover:bg-blue-600"} 
        text-white font-bold py-4 px-6 rounded-xl shadow-lg transition-all duration-200
        ${className}
      `}
    >
      <span className="text-2xl mr-3">{getButtonIcon()}</span>
      <span className="text-lg">{getButtonText()}</span>
    </Button>
  )
}
