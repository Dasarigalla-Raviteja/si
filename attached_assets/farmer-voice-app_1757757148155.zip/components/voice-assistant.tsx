"use client"

import type React from "react"
import { useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { useVoiceSupport } from "@/hooks/use-voice-support"

interface VoiceAssistantProps {
  onWeatherRequest?: () => void
  onPricesRequest?: () => void
  onHelpRequest?: () => void
  language?: string
  autoGreet?: boolean
}

export const VoiceAssistant: React.FC<VoiceAssistantProps> = ({
  onWeatherRequest,
  onPricesRequest,
  onHelpRequest,
  language = "hi-IN",
  autoGreet = true,
}) => {
  const {
    isListening,
    isSpeaking,
    recognizedText,
    isSupported,
    currentStatus,
    speak,
    startListening,
    stopListening,
    messages,
    processCommand,
  } = useVoiceSupport({ language })

  // Auto-greet on mount
  useEffect(() => {
    if (autoGreet && isSupported) {
      setTimeout(() => {
        speak(messages.greeting)
        setTimeout(() => {
          speak(messages.mainMenu)
        }, 4000)
      }, 1000)
    }
  }, [autoGreet, isSupported, messages, speak])

  // Handle voice commands
  useEffect(() => {
    if (recognizedText) {
      const result = processCommand(recognizedText)

      // Handle specific commands
      setTimeout(() => {
        switch (result.category) {
          case "weather":
            speak(messages.confirmation)
            setTimeout(() => {
              if (onWeatherRequest) {
                onWeatherRequest()
              } else {
                speak("आज धूप है। तापमान 25 डिग्री है। खेत का काम कर सकते हैं।")
              }
            }, 1500)
            break
          case "prices":
            speak(messages.confirmation)
            setTimeout(() => {
              if (onPricesRequest) {
                onPricesRequest()
              } else {
                speak("गेहूं 2000 रुपये क्विंटल। चावल 1800 रुपये क्विंटल।")
              }
            }, 1500)
            break
          case "help":
            if (onHelpRequest) {
              onHelpRequest()
            } else {
              speak(messages.mainMenu)
            }
            break
          case "repeat":
            speak(`${messages.mainMenu}`)
            break
          case "stop":
            stopListening()
            break
        }
      }, 1000)
    }
  }, [recognizedText, processCommand, messages, speak, onWeatherRequest, onPricesRequest, onHelpRequest, stopListening])

  const handleMicClick = () => {
    if (!isSupported) return

    speak("बटन दबाया गया")
    setTimeout(() => {
      if (isListening) {
        stopListening()
      } else {
        startListening()
      }
    }, 800)
  }

  const handleRepeatClick = () => {
    speak("मैं फिर से बताता हूं")
    setTimeout(() => {
      speak(messages.mainMenu)
    }, 1500)
  }

  if (!isSupported) {
    return (
      <Card className="w-full max-w-md mx-auto bg-red-50 border-red-200">
        <CardContent className="p-6 text-center">
          <div className="text-4xl mb-4">⚠️</div>
          <p className="text-red-700 font-medium">{messages.notSupported}</p>
        </CardContent>
      </Card>
    )
  }

  const getStatusIcon = () => {
    switch (currentStatus) {
      case "listening":
        return "🎙️"
      case "speaking":
        return "🔊"
      case "processing":
        return "⚙️"
      case "error":
        return "❌"
      default:
        return "👂"
    }
  }

  const getStatusText = () => {
    switch (currentStatus) {
      case "listening":
        return "सुन रहा हूं..."
      case "speaking":
        return "बोल रहा हूं..."
      case "processing":
        return "समझ रहा हूं..."
      case "error":
        return "त्रुटि हुई"
      default:
        return "तैयार हूं"
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto bg-gradient-to-br from-green-50 to-blue-50">
      <CardHeader className="bg-green-500 text-white text-center rounded-t-lg">
        <CardTitle className="text-xl font-bold">🌾 किसान सहायक</CardTitle>
        <p className="text-green-100 text-sm">Voice Assistant for Farmers</p>
      </CardHeader>

      <CardContent className="p-6 space-y-6">
        {/* Status Display */}
        <div className="bg-white rounded-xl p-6 text-center shadow-sm border">
          <div className="text-4xl mb-3">{getStatusIcon()}</div>
          <div className="text-lg font-semibold text-green-700 mb-2">{getStatusText()}</div>
          {recognizedText && <div className="text-sm text-gray-600 italic">आपने कहा: "{recognizedText}"</div>}
        </div>

        {/* Main Controls */}
        <div className="space-y-4">
          {/* Primary Mic Button */}
          <Button
            onClick={handleMicClick}
            disabled={isSpeaking}
            className={`
              w-full py-6 text-lg font-bold rounded-xl shadow-lg transition-all duration-200
              ${isListening ? "bg-red-500 hover:bg-red-600 animate-pulse" : "bg-blue-500 hover:bg-blue-600"}
            `}
          >
            <span className="text-2xl mr-3">{isListening ? "🔴" : "🎙️"}</span>
            <div className="flex flex-col">
              <span>{isListening ? "सुन रहा हूं" : "यहाँ दबाएं"}</span>
              <span className="text-sm opacity-90">{isListening ? "अब बोलें" : "बोलने के लिए"}</span>
            </div>
          </Button>

          {/* Repeat Button */}
          <Button
            onClick={handleRepeatClick}
            disabled={isSpeaking}
            variant="outline"
            className="w-full py-4 text-base font-semibold border-2 border-purple-300 text-purple-700 hover:bg-purple-50 bg-transparent"
          >
            <span className="text-xl mr-2">🔄</span>
            दोबारा सुनें
          </Button>
        </div>

        {/* Instructions */}
        <div className="bg-white rounded-xl p-4 shadow-sm border">
          <h3 className="font-bold text-green-700 text-center mb-3">बोल सकते हैं:</h3>
          <div className="space-y-2">
            <div className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
              <span className="text-xl">🌤️</span>
              <span className="font-medium text-green-600">"मौसम"</span>
            </div>
            <div className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
              <span className="text-xl">💰</span>
              <span className="font-medium text-green-600">"कीमत"</span>
            </div>
            <div className="flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
              <span className="text-xl">❓</span>
              <span className="font-medium text-green-600">"मदद"</span>
            </div>
          </div>
        </div>

        {/* Footer Status */}
        <div className="text-center p-3 bg-green-100 rounded-lg border border-green-200">
          <span className="text-green-700 font-medium">
            {isSpeaking ? "🔊 बोल रहा हूं..." : isListening ? "👂 सुन रहा हूं..." : "✅ तैयार हूं - बटन दबाएं"}
          </span>
        </div>
      </CardContent>
    </Card>
  )
}
