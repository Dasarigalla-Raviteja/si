"use client"

import { useState, useEffect, useCallback, useRef } from "react"
import type SpeechRecognition from "speech-recognition"
import type SpeechSynthesis from "speech-synthesis"

interface VoiceConfig {
  language?: string
  rate?: number
  pitch?: number
  volume?: number
}

interface VoiceMessages {
  greeting?: string
  mainMenu?: string
  listening?: string
  processing?: string
  notUnderstood?: string
  error?: string
  confirmation?: string
  notSupported?: string
}

interface VoiceCommands {
  [key: string]: string[]
}

export const useVoiceSupport = (
  config: VoiceConfig = {},
  customMessages: VoiceMessages = {},
  customCommands: VoiceCommands = {},
) => {
  const [isListening, setIsListening] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [recognizedText, setRecognizedText] = useState("")
  const [isSupported, setIsSupported] = useState(false)
  const [currentStatus, setCurrentStatus] = useState<"ready" | "listening" | "speaking" | "processing" | "error">(
    "ready",
  )

  const recognitionRef = useRef<SpeechRecognition | null>(null)
  const synthRef = useRef<SpeechSynthesis | null>(null)
  const timeoutRef = useRef<NodeJS.Timeout | null>(null)

  // Default configuration
  const defaultConfig = {
    language: "hi-IN",
    rate: 0.6,
    pitch: 0.9,
    volume: 1,
    ...config,
  }

  // Default messages in Hindi
  const defaultMessages = {
    greeting: "नमस्ते! मैं आपका सहायक हूं। नीले बटन को दबाकर बोलें।",
    mainMenu: "आप कह सकते हैं - मौसम, कीमत, या मदद।",
    listening: "सुन रहा हूं... अब बोलें",
    processing: "समझ रहा हूं...",
    notUnderstood: "मैं समझ नहीं पाया। फिर से बोलें।",
    error: "कोई समस्या है। फिर कोशिश करें।",
    confirmation: "ठीक है, समझ गया",
    notSupported: "आपका ब्राउज़र आवाज़ की सुविधा नहीं देता। कृपया Chrome या Firefox का उपयोग करें।",
    ...customMessages,
  }

  // Default voice commands
  const defaultCommands = {
    weather: ["मौसम", "weather", "बारिश", "धूप", "ठंड", "गर्मी"],
    prices: ["कीमत", "भाव", "price", "दाम", "रेट", "मंडी"],
    help: ["मदद", "help", "सहायता", "बताओ", "क्या", "कैसे"],
    repeat: ["फिर", "दोबारा", "repeat", "again", "वापस"],
    stop: ["रुको", "stop", "बंद", "चुप"],
    ...customCommands,
  }

  // Initialize speech APIs
  useEffect(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    const SpeechSynthesis = window.speechSynthesis

    if (SpeechRecognition && SpeechSynthesis) {
      setIsSupported(true)

      // Setup speech recognition
      recognitionRef.current = new SpeechRecognition()
      recognitionRef.current.continuous = false
      recognitionRef.current.interimResults = false
      recognitionRef.current.lang = defaultConfig.language

      // Setup speech synthesis
      synthRef.current = SpeechSynthesis

      // Recognition event handlers
      recognitionRef.current.onstart = () => {
        setIsListening(true)
        setCurrentStatus("listening")
      }

      recognitionRef.current.onresult = (event) => {
        const transcript = event.results[0][0].transcript.toLowerCase()
        setRecognizedText(transcript)
        setCurrentStatus("processing")

        // Process command after brief delay
        setTimeout(() => {
          processCommand(transcript)
        }, 1000)
      }

      recognitionRef.current.onerror = (event) => {
        console.error("Speech recognition error:", event.error)
        setIsListening(false)
        setCurrentStatus("error")

        setTimeout(() => {
          speak(defaultMessages.error)
          setCurrentStatus("ready")
        }, 1000)
      }

      recognitionRef.current.onend = () => {
        setIsListening(false)
        if (currentStatus === "listening") {
          setCurrentStatus("ready")
        }
      }
    } else {
      setIsSupported(false)
    }

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.abort()
      }
      if (synthRef.current) {
        synthRef.current.cancel()
      }
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current)
      }
    }
  }, [defaultConfig.language])

  const speak = useCallback(
    (text: string, onEnd?: () => void) => {
      if (!synthRef.current || !isSupported) return

      // Cancel any ongoing speech
      synthRef.current.cancel()

      const utterance = new SpeechSynthesisUtterance(text)
      utterance.lang = defaultConfig.language
      utterance.rate = defaultConfig.rate
      utterance.pitch = defaultConfig.pitch
      utterance.volume = defaultConfig.volume

      utterance.onstart = () => {
        setIsSpeaking(true)
        setCurrentStatus("speaking")
      }

      utterance.onend = () => {
        setIsSpeaking(false)
        setCurrentStatus("ready")
        if (onEnd) onEnd()
      }

      utterance.onerror = () => {
        setIsSpeaking(false)
        setCurrentStatus("ready")
      }

      synthRef.current.speak(utterance)
    },
    [defaultConfig, isSupported],
  )

  const processCommand = useCallback(
    (command: string) => {
      // Find matching command
      for (const [category, keywords] of Object.entries(defaultCommands)) {
        if (keywords.some((keyword) => command.includes(keyword))) {
          return { category, command }
        }
      }

      // No command found
      speak(`${defaultMessages.notUnderstood} ${defaultMessages.mainMenu}`)
      return { category: "unknown", command }
    },
    [defaultCommands, defaultMessages, speak],
  )

  const startListening = useCallback(async () => {
    if (!recognitionRef.current || isListening || isSpeaking || !isSupported) return

    try {
      setRecognizedText("")
      recognitionRef.current.start()

      // Provide audio feedback after starting
      timeoutRef.current = setTimeout(() => {
        if (isListening) {
          speak(defaultMessages.listening)
        }
      }, 500)
    } catch (error) {
      console.error("Error starting recognition:", error)
      speak(defaultMessages.error)
    }
  }, [isListening, isSpeaking, isSupported, defaultMessages, speak])

  const stopListening = useCallback(() => {
    if (recognitionRef.current && isListening) {
      recognitionRef.current.abort()
    }
  }, [isListening])

  const stopSpeaking = useCallback(() => {
    if (synthRef.current) {
      synthRef.current.cancel()
    }
  }, [])

  return {
    // State
    isListening,
    isSpeaking,
    recognizedText,
    isSupported,
    currentStatus,

    // Actions
    speak,
    startListening,
    stopListening,
    stopSpeaking,
    processCommand,

    // Messages and commands for external use
    messages: defaultMessages,
    commands: defaultCommands,
  }
}
